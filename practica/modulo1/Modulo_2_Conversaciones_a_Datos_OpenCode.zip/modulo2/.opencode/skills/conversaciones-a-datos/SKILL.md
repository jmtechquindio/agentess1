---
name: conversaciones-a-datos
description: Convierte el archivo JSON dataset en datos verificables para el entregable del Módulo 02 de Fundación Cognitus
---

# Skill: conversaciones-a-datos

## Objetivo

Procesar el archivo JSON llamado `dataset` que se encuentre en la carpeta de trabajo y convertir sus conversaciones en datos estructurados y verificables.

Seguir estrictamente las instrucciones del entregable Módulo 02 de Fundación Cognitus:
- No inventar información.
- No modificar el archivo JSON original.
- Conservar `conversation_id`.
- Procesar entre 100 y 300 conversaciones.
- Validar conteos, identificadores, tipos, nulos y trazabilidad.
- Separar información pendiente o ambigua.
- Responder tres preguntas de negocio únicamente con evidencia obtenida del dataset.
- Generar una salida CSV, Excel o SQLite.
- Preparar un dashboard estático.
- Documentar límites y decisiones.

## Entrada

La entrada es el archivo JSON llamado `dataset`.

Normalmente deberá estar disponible como `dataset.json` en la carpeta de trabajo.

Antes de procesarlo:
1. Localiza `dataset.json`.
2. Si existe otro archivo con nombre base `dataset`, identifica su formato antes de procesarlo.
3. No sobrescribas ni modifiques el archivo original.
4. Verifica que el JSON pueda cargarse correctamente.
5. Identifica la estructura real antes de definir campos.
6. No asumas que los campos sugeridos por el curso existen exactamente así: compruébalos en los datos reales.

## Proceso

### 1. Inspección inicial

Determina y registra:
- cantidad total de conversaciones;
- estructura principal del JSON;
- nombres exactos de los campos;
- presencia de `conversation_id`;
- estructura de mensajes/intervenciones;
- campos disponibles dentro de cada mensaje;
- información relevante para negocio.

No inventes campos que no existan.

### 2. Definir las preguntas de negocio

Primero analiza qué información está realmente disponible. Después define tres preguntas de negocio que puedan responderse con evidencia del dataset.

No elijas una pregunta si el dataset no contiene información suficiente para responderla.

### 3. Diseñar el esquema

Define qué representa una fila y documenta:
- nombre del campo;
- significado;
- tipo de dato;
- regla de extracción;
- si es obligatorio;
- qué ocurre cuando el dato no aparece;
- qué ocurre cuando el dato es ambiguo.

La información no explícita debe quedar como pendiente/ambigua y no debe ser inventada.

### 4. Extracción

Procesa las conversaciones conservando:
- `conversation_id`;
- evidencia necesaria para comprobar cada dato extraído;
- información estructurada requerida por las preguntas de negocio.

### 5. Validación

Comprueba como mínimo:
- cantidad de conversaciones de entrada;
- cantidad procesada;
- cantidad pendiente;
- cantidad ambigua;
- identificadores;
- tipos de datos;
- valores nulos;
- trazabilidad hacia la conversación original.

Debe cumplirse:

`procesadas + pendientes/ambiguas = total de entrada`

Si una conversación no puede clasificarse correctamente, regístrala como pendiente o ambigua.

### 6. Evidencia

Cada resultado utilizado para responder las preguntas de negocio debe poder rastrearse hasta uno o más `conversation_id`.

No generes cifras, porcentajes, categorías o conclusiones que no puedan demostrarse con el dataset.

### 7. Salidas

Genera:
- datos estructurados en CSV, Excel o SQLite;
- archivo separado de pendientes y excepciones;
- informe con las tres preguntas, respuestas y evidencia;
- límites y decisiones tomadas;
- dashboard estático.

## Reglas estrictas

1. No inventar datos.
2. No completar información faltante mediante suposiciones.
3. No modificar el JSON original.
4. No mezclar datasets diferentes.
5. No introducir conversaciones personales, teléfonos reales ni información identificable ajena al dataset suministrado.
6. No presentar como hecho una inferencia que no esté respaldada.
7. Mantener `conversation_id` para permitir trazabilidad.
8. Si existe ambigüedad, conservarla y registrarla.
9. Si una pregunta no puede responderse con los datos disponibles, indicarlo claramente.
10. Antes de generar resultados finales, verificar la reconciliación de los registros.

## Salida esperada

La carpeta de trabajo debe contener, como mínimo:
- `dataset.json` original sin modificaciones;
- archivo de datos procesados;
- archivo de pendientes/excepciones;
- informe de las tres preguntas;
- dashboard estático;
- documentación del proceso.

Los nombres concretos de los archivos de salida pueden adaptarse al entorno de OpenCode, pero no deben reemplazar ni modificar `dataset.json`.

## Criterio de finalización

El trabajo solo se considera terminado cuando:
- se identificó y procesó el dataset real;
- se verificó el número de conversaciones;
- se definieron tres preguntas basadas en los datos disponibles;
- se documentó el esquema;
- se procesaron entre 100 y 300 conversaciones;
- se conservó `conversation_id`;
- se validaron tipos y nulos;
- se separaron pendientes y ambigüedades;
- los conteos reconcilian;
- las tres preguntas tienen respuestas verificables;
- existe evidencia para las respuestas;
- se documentaron límites y decisiones;
- existe un dashboard estático.
